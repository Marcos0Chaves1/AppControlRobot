
// CADASTRO DE UM NOVO BANCO E ABRE ELE COM OPEN
var request, db;
window.indexedDB = window.indexedDB || window.mozIndexedDB || 
window.webkitIndexedDB || window.msIndexedDB;

if(!window.indexedDB){
    navigator.notification.alert("Não suporta BD");
}else{
    request = window.indexedDB.open("Unoesc", 1);
    request.onerror = function(event){
        navigator.notification.alert("Erro ao abrir o BD");
    }
    request.onupgradeneeded = function (event) {
        db = event.target.result;
        var objectStore = db.createObjectStore("controle", {keyPath:"id", 
            autoIncrement: true});
            objectStore.createIndex("senha_nome", ['tipo', 'valor'], {unique: true});
    };
    request.onsuccess = function (event) {
        db = event.target.result;
    }
}

// EDITAR USUARIO EXISTENTE
$("#btn_editar").on('click', function(){
    var senha = document.getElementById("input_senha").value;// aqui pega o valor do campo senha digitado
    var usuario = document.getElementById("input_nome").value; // aqui pega o valor do campo nome digitado  

    if((usuario==="")||(senha==="")){ // verifica se o nome e ou senha estão vazios
        alert("Informe seu nome e senha para alterar "+usuario + " "+senha);
        document.getElementById("input_nome").focus(); // seta o foco para o input do nome
        
     
     }else{ // havendo informações salva no banco
        alert("Informe seu novo nome e senha para alterar "+usuario + " "+senha);
        document.getElementById("input_nome").focus(); // seta o foco para o input do nome

        var transaction = db.transaction(["controle"], "readwrite");                                                
        var objectStore = transaction.objectStore("controle");    
        objectStore.openCursor(null, "prev").onsuccess = function(event){        
            var cursor = event.target.result;
            if(cursor){
               if((cursor.value.tipo == senha) && (cursor.value.valor == usuario)){   
                    var request = objectStore.get(parseInt(cursor.value.id));
                    request.onsuccess = function(event){
                    var data = event.target.result;
                    usuario = prompt("Digite seu novo Usuario:");
                    senha = prompt("Digite sua nova senha:");
                    if((usuario==="")||(senha==="")||(usuario===null)||(senha===null)){
                        alert("Voce não informou um usuário e senha !");
                        return;
                    }   
                    data.valor = usuario;
                    data.tipo = senha;
                    var requestUpdate = objectStore.put(data);
                        requestUpdate.onerror = function(event){
                            alert("Erro ao editar "+cursor.value.id);
                        };
                        requestUpdate.onsuccess = function(event){
                            alert("Usuário editado com sucesso "+cursor.value.id);
                            location.href = "index.html";
                        }; 
                   }               
                            
                };cursor.continue()
            }
        }       
    }  
});

// CADASTRAR NOVO USUARIO
$("#btn_cadastrar").on('click', function(){
    var nome = $("[name=input_nome]").val();// pega o valor inserido no input de id="input_nome"
    var senha= $("[name=input_tipo]").val();// pega o valor inserido no input de id="input_tipo"
    var transaction = db.transaction(["controle"], "readwrite");//abre uma transação que lê ou insere no banco"                                               
    var objectStore = transaction.objectStore("controle");// variavel para acessar os dados da tabela no banco
    if(nome=="" || senha==""){ // verifica se o nome está vazio
       document.getElementById("input_nome").focus(); // seta o foco para o input do nome
       alert("Você não informou um usuario ou senha! ");
    }else{ // havendo informações salva no banco
        objectStore.add({valor: nome, tipo: senha}); // salva as informaçoes no banco
    
        transaction.oncomplete = function(event){ // havendo exito no registro das informaçãoes exibe a mensagem
            alert("cadastrado com sucesso "+nome+" "+senha);
        }
    }
});

// VELOCIDADE DO ROBO (NORTE OU SUL)
$("#rg_veloz").on('input', function(){
    var velocidade = this.value;
    mv = document.getElementById("hw_velocidade");
    mv.value = velocidade;   
});

// DIREÇÃO DO ROBO (LESTE OU OESTE)
$("#rg_direcao").on('input', function(){
    var posicao = this.value;
    var direcao; 
    mv = document.getElementById("hw_direcao");
    if(posicao>0){
        direcao = "Direita";
    }
    if(posicao<0){
        direcao = "Esquerda";
    }
    if(posicao == 0){(direcao= "Neutra");}

    mv.value = direcao;   
});

// APAGAR USUARIO
$("#btn_apagar").on('click', function(){
    var senha = document.getElementById("input_senha").value;        // aqui pega o valor do campo senha digitado
    var usuario = document.getElementById("input_nome").value;       // aqui pega o valor do campo nome digitado    
    var transaction = db.transaction(["controle"], "readwrite");                                                
    var objectStore = transaction.objectStore("controle");    
    objectStore.openCursor(null, "prev").onsuccess = function(event){        
        var cursor = event.target.result;
        if(cursor){
            var aux = 0;
           if((cursor.value.tipo == senha) && (cursor.value.valor == usuario)){                  
                var id =  cursor.value.id;
                aux = 1;
                //alert("Id do usuario a ser excluido: " + id);
                var transacao = transaction.objectStore("controle").delete(id);
                console.log(transacao);
                transacao.onsuccess = function(event){
                    alert("Usuario  '" + usuario + "'  foi excluido com sucesso");
                }
                transacao.onerror = function(event){
                    alert("Não foi possivel excluir o usuario  '" + usuario + "'  !");
                }          
            }
            cursor.continue()
        }
    }
    if(aux === 0){
        alert(" Usuario incorreto! tente novamente! ");
    }
});

// LOGIN
$("#btn_acessar").on('click', function(){
    var senha = document.getElementById("input_senha").value;// aqui pega o valor do campo senha digitado
    var usuario = document.getElementById("input_usuario").value; // aqui pega o valor do campo nome digitado
    var transaction = db.transaction('controle', "readonly"); // variavel para acessar o banco
    var objectStore = transaction.objectStore('controle');// variavel para acessar os dados da tabela no banco
    var index = objectStore.index("senha_nome");// pega os valores correspondentes do nome e senhacomo indice salvos no banco
  
    var login = IDBKeyRange.only([senha, usuario]);// login recebe as credenciais do usuário
    var requestUser =  index.openCursor(login);// existindo essas credenciais no banco elas são acessadas
    requestUser.onsuccess = function (event){// conseguindo acessar as credenciais no banco o usuário realiza login
        var cursor = event.target.result;
        if(cursor){
            alert("Login Realizado com sucesso! Bem vindo " + usuario);
            location.href = "Controle.html";
        }else{ alert(" Verefique as informações: usuário ou senha inválidos!");
            document.getElementById("input_usuario").focus();
        }
    }   
    
});